from typing import TYPE_CHECKING, Collection, Dict, List, Mapping, Optional, Set
from melder.aether.spellbook.spell_compiler.phases.shared_compiler_executions import (
    SharedCompilerExecutions,
)
from melder.aether.spellbook.existence.existence import Existence
from melder.aether.spellbook.spell_compiler.system.spell_system_adjacency_builder import (
    SpellSystemAdjacencyBuilder,
)
from melder.aether.spellbook.spell_compiler.system.spell_system_adjacency_snapshot import (
    SpellSystemAdjacencySnapshot,
)
from melder.aether.spellbook.spell_compiler.system.spell_system_index import (
    SpellSystemIndex,
)
from melder.aether.spellbook.spell_compiler.system.spell_system_node import (
    SpellSystemNode,
)
from melder.aether.spellbook.spell_compiler.system.spell_system_root_blueprint_builder import (
    SpellSystemRootBlueprintBuilder,
)

if TYPE_CHECKING:
    from melder.aether.spellbook.spell_compiler.blueprints.root_resolution_blueprint import (
        RootResolutionBlueprint,
    )
    from melder.aether.spellbook.spell import Spell
    from melder.aether.spellbook.spellbook import Spellbook
    from melder.aether.aetheric_frame.dev_ops.spell_system_states.spell_system_state import (
        SpellSystemState,
    )
    from melder.aether.aetheric_frame.dev_ops.spell_system_states.spell_system_states import (
        SpellSystemStates,
    )
    from melder.aether.spellbook.spell_compiler.spell_compiler_artifact import (
        SpellCompilerArtifact,
    )
    from melder.aether.spellbook.spell_compiler.topology.spell_local_topology import (
        SpellLocalTopology,
    )
    from melder.utilities.synchronization.cancellation_event_signal import (
        CancellationEvent,
    )






class CompilerPhase5:
    """
    Compiler phase 5 surface.

    Purpose:
        Expose the current rooted-blueprint build behaviour through a compiler-
        owned phase class.

    Contract:
        - Slot-only phase surface with no explicit `__init__`.
        - Directly ports the canonical `SpellCrafter` phase-5 behaviour.
        - Does not own spell, artifact, spellbook, or runtime collaborator
          lifecycle.
        - Dependency visibility does not grant artifact publication authority:
          publish only for spells included in the pass's own compilation scope.
        - Executable snapshots exclude non-resolvable definitions; their registration
          and local topology remain available through their original owners.
    """

    __slots__ = ()

    def _get_required_spellbook_frame_name(self, spellbook: Spellbook) -> str:
        """
            Return the non-empty owning frame name for one spellbook or raise.
            
            Args:
                spellbook:
                    Owning a spellbook whose frame name is required.
            
            Returns:
                str: Concrete-owning frame name.
            
            Raises:
                RuntimeError:
                    If the spellbook does not currently expose a concrete frame
                    name.
        """
        frame_name = spellbook._aetheric_frame_name
        if frame_name is None:
            raise RuntimeError("SpellCrafter requires a concrete owning frame name.")
        return frame_name

    def _get_required_current_spell_id(self, spell: Spell) -> str:
        """
        Resolve the current spell version id for the bound spell.

        Args:
            spell:
                Spell expected to have a current version id.

        Returns:
            str: Current spell id.

        Raises:
            RuntimeError:
                If the spell has no current version id.
        """
        current_spell_id = spell.spell_index.selected_spell_id
        if current_spell_id is None:
            raise RuntimeError("SpellCrafter requires a bound spell current id.")
        return current_spell_id

    def _get_required_spell_system_states(
            self,
            spell_system_states: SpellSystemStates,
    ) -> SpellSystemStates:
        """
        Require a live SpellSystemStates collaborator.

        Args:
            spell_system_states:
                Candidate collaborator.

        Returns:
            SpellSystemStates: Validated SpellSystemStates.

        Raises:
            RuntimeError:
                If the state registry is missing.
        """
        if spell_system_states is None:
            raise RuntimeError(
                "SpellCrafter requires a live SpellSystemStates surface."
            )
        return spell_system_states

    def _get_required_spell_state_by_spell_id(
            self,
            spell_system_states: SpellSystemStates,
            spell_id: str,
    ) -> SpellSystemState:
        """
        Resolve the spell-system state for a given spell id.

        Args:
            spell_system_states:
                Validated SpellSystemStates view.
            spell_id:
                Spell id to resolve.

        Returns:
            SpellSystemState: Resolved state for the requested spell id.

        Raises:
            RuntimeError:
                If no spell state exists for `spell_id`.
        """
        state = self._get_required_spell_system_states(
            spell_system_states
        ).get_by_spell_id(spell_id)
        if state is None:
            raise RuntimeError(
                "SpellCrafter requires a live SpellSystemState for spell id "
                f"'{spell_id}'."
            )
        return state

    def _set_root_blueprint_phase5(
            self,
            spell: Spell,
            artifact: SpellCompilerArtifact,
            blueprint: RootResolutionBlueprint,
    ) -> None:
        """
        Attach the Phase 5 root blueprint for this spell.

        Contract:
            - Stores the owned-root blueprint that later validation and plan
              phases consume.
            - Refreshes Phase 2-5 exported IR.
            - Invalidates later Phase 8-11 IR caches because they depend on the
              rooted blueprint shape.
        """
        artifact.check_cleaned()
        if blueprint is None:
            raise ValueError("blueprint must not be None.")
        artifact._root_blueprint_phase5 = blueprint
        artifact._requires_spellspace_request_phase5 = blueprint.requires_spellspace_request
        spell.requires_spellspace_request = blueprint.requires_spellspace_request
        # Eager phase2_5 IR capture removed (write-only; see compiler_phase_2).
        # The downstream invalidations below are real state transitions and
        # must stay.
        artifact._cleanup_occurrence_analysis_artifacts()
        artifact._cleanup_codegen_outputs()
        spell._cleanup_creation_context()

    def _set_spell_system_index_phase5(
            self,
            spell: Spell,
            artifact: SpellCompilerArtifact,
            index: SpellSystemIndex,
    ) -> None:
        """
        Attach the Phase 5 spell-system index for this spell.

        Contract:
            - Stores the spell-local handle to the wider system index.
            - Refreshes Phase 2-5 exported IR.
            - Invalidates later Phase 8-11 IR caches because downstream
              planning may depend on index content.
        """
        artifact.check_cleaned()
        if index is None:
            raise ValueError("index must not be None.")
        artifact._spell_system_index_phase5 = index
        # Eager phase2_5 IR capture removed (write-only; see compiler_phase_2).
        artifact._cleanup_occurrence_analysis_artifacts()
        artifact._cleanup_codegen_outputs()
        spell._cleanup_creation_context()

    def _collect_local_scope_spell_ids(
            self,
            *,
            root_spell_id: str,
            snapshot: SpellSystemAdjacencySnapshot,
    ) -> Set[str]:
        """
        Collect dependency-closure spell ids for local Phase 5-7 execution.

        Purpose:
            Limit local Phase 5-7 execution to the target spell and all spells
            it depends on directly or transitively.
        Contract:
            - Traverses dependency edges from root to leaves.
            - Returns only ids present in the provided snapshot.
            - Never mutates the snapshot.
        Args:
            root_spell_id:
                Target spell id whose dependency closure should be resolved.
            snapshot:
                Visibility-filtered adjacency snapshot.
        Returns:
            Set[str]:
                Target spell id plus dependency closure.
        """
        if root_spell_id not in snapshot.all_spell_ids:
            return set()

        scoped_spell_ids: Set[str] = set()
        pending: List[str] = [root_spell_id]

        while pending:
            spell_id = pending.pop()
            if spell_id in scoped_spell_ids:
                continue
            if spell_id not in snapshot.all_spell_ids:
                continue
            scoped_spell_ids.add(spell_id)
            for dependency_id in snapshot.dependencies.get(spell_id, ()):
                if dependency_id not in scoped_spell_ids:
                    pending.append(dependency_id)

        return scoped_spell_ids

    def _build_system_index_for_snapshot(
            self,
            *,
            snapshot: SpellSystemAdjacencySnapshot,
            spell_lookup: Dict[str, Spell],
            spell_system_states: SpellSystemStates,
    ) -> tuple[SpellSystemIndex, Set[str]]:
        """
        Build a SpellSystemIndex for a pre-filtered adjacency snapshot.

        Purpose:
            Share index construction between frame-wide and local Phase 5 paths.
        Contract:
            - Requires every snapshot spell id to be present in "spell_lookup".
            - Resolves lineage ids from SpellSystemStates.
            - Does not mutate snapshot or spell_lookup.
        Args:
            snapshot:
                Snapshot to materialize into an index.
            spell_lookup:
                Visible spell_id -> spell map.
            spell_system_states:
                Borrowed SpellSystemStates surface.
        Returns:
            SpellSystemIndex:
                Index populated for all snapshot spell ids.
        """
        system_index = SpellSystemIndex()
        spellspace_scoped_spell_ids: Set[str] = set()
        for spell_id, deps in snapshot.dependencies.items():
            lineage_id = self._get_required_spell_state_by_spell_id(
                spell_system_states,
                spell_id,
            ).spell_index_id
            spell_instance = spell_lookup[spell_id]
            if spell_instance.existence is Existence.unique_per_spell_space:
                spellspace_scoped_spell_ids.add(spell_id)

            node = SpellSystemNode(
                spell_id=spell_id,
                lineage_id=lineage_id,
                dependencies=deps,
                existence=spell_instance.existence,
                spell_type=spell_instance.spell_type,
                conduit_id=spell_instance._owner_conduit_id,
                ward_id=None,
                is_root=spell_id in snapshot.root_spell_ids,
            )
            system_index.upsert_node(node)

        return system_index, spellspace_scoped_spell_ids

    def _attach_phase5_artifacts_for_snapshot(
            self,
            *,
            snapshot: SpellSystemAdjacencySnapshot,
            root_blueprints: Mapping[str, RootResolutionBlueprint],
            system_index: SpellSystemIndex,
            spell_lookup: Dict[str, Spell],
            root_builder: SpellSystemRootBlueprintBuilder,
            publication_spell_ids: Collection[str],
    ) -> None:
        """
        Attach Phase 5 artifacts only to the pass's publication targets.

        Purpose:
            Prepare canonical artifacts for spells this pass will compile,
            preserving other visible providers' executable state and contexts.
        Contract:
            - Updates only snapshot IDs also in publication_spell_ids.
            - Keeps the complete visible snapshot for dependency analysis.
            - Does not invalidate artifacts on excluded dependency spells.
            - Existing-creation spells get index only and skip blueprints.
            - Builds fallback per-spell blueprint when not present as a root.
        Args:
            snapshot:
                Scoped adjacency snapshot.
            root_blueprints:
                Root blueprint map produced for this snapshot.
            system_index:
                System index for this snapshot.
            spell_lookup:
                Visible spell_id -> spell map.
            root_builder:
                Builder used for per-spell fallback blueprints.
            publication_spell_ids:
                Canonical publication scope: owned IDs for a conduit-wide pass,
                or the selected target ID for a target-local pass. The caller
                supplies this separately from dependency visibility.
        Returns:
            None.
        """
        for spell_id in snapshot.all_spell_ids:
            if spell_id not in publication_spell_ids:
                continue
            spell_instance = spell_lookup[spell_id]
            target_artifact = spell_instance._compiler_artifact
            self._set_spell_system_index_phase5(
                spell_instance,
                target_artifact,
                system_index,
            )

            if spell_instance.is_existing_creation:
                continue

            blueprint = root_blueprints.get(spell_id)
            if blueprint is None:
                blueprint = root_builder.build_blueprint_for_spell_id(
                    root_spell_id=spell_id,
                    snapshot=snapshot,
                )
            self._set_root_blueprint_phase5(
                spell_instance,
                target_artifact,
                blueprint,
            )

    def _filter_snapshot_to_visible_spells(
            self,
            *,
            snapshot: SpellSystemAdjacencySnapshot,
            visible_spell_ids: Collection[str],
    ) -> SpellSystemAdjacencySnapshot:
        """
            Internal
            
            Filter a frame-wide adjacency snapshot to spells visible in this Spellbook.
            
            Purpose:
                Ensure Phase-5/6 validation only considers spells that the current
                Spellbook can resolve (local + contracted).
            Contract:
                - Dependency sets are referenced directly from the adjacency view.
                - Reverse edges and root spell ids are recomputed using visible spell ids.
                - Topologies are retained only for visible spell ids.
            Args:
                snapshot:
                    Frame-wide SpellSystemAdjacencySnapshot to filter.
                visible_spell_ids:
                    Version ids are visible to this Spellbook. This collection is treated
                    as a live view and is not copied.
            Returns:
                SpellSystemAdjacencySnapshot:
                    A filtered snapshot scoped to the provided spell ids.
        """
        all_spell_ids: Collection[str] = visible_spell_ids
        dependencies: Dict[str, Set[str]] = {}
        reverse_dependencies: Dict[str, Set[str]] = {}
        topologies: Optional[Dict[str, Optional[SpellLocalTopology]]] = None
        snapshot_topologies = snapshot.topologies
        if snapshot_topologies is not None:
            topologies = {}

        for spell_id in all_spell_ids:
            deps = snapshot.dependencies.get(spell_id, set())
            filtered_deps = {dep_id for dep_id in deps if dep_id in all_spell_ids}
            dependencies[spell_id] = filtered_deps
            for dep_id in filtered_deps:
                reverse_dependencies.setdefault(dep_id, set()).add(spell_id)

            if (
                topologies is not None
                and snapshot_topologies is not None
                and spell_id in snapshot_topologies
            ):
                topologies[spell_id] = snapshot_topologies.get(spell_id)

        root_spell_ids = {spell_id for spell_id in all_spell_ids if spell_id not in reverse_dependencies}

        return SpellSystemAdjacencySnapshot(
            dependencies=dependencies,
            reverse_dependencies=reverse_dependencies,
            all_spell_ids=all_spell_ids,
            root_spell_ids=root_spell_ids,
            topologies=topologies,
        )

    def _filter_root_blueprints_to_owned(
            self,
            spellbook: Spellbook,
            root_blueprints: Mapping[str, RootResolutionBlueprint],
    ) -> Dict[str, RootResolutionBlueprint]:
        """
            Internal
            
            Filter root blueprints to owned spell ids only.
            
            Purpose:
                Limit component-of rebuilds to spell ids owned by this Spellbook
                while still allowing contracted spells to appear as dependencies
                under owned roots.
            Contract:
                - Returns a new mapping containing only roots present in
                  `spellbook._spells_by_id`.
                - Does not mutate the provided root_blueprints mapping.
            Args:
                root_blueprints:
                    Mapping of root spell_id to RootResolutionBlueprint.
            Returns:
                Dict[str, RootResolutionBlueprint]:
                    Filtered mapping containing only owned roots.
        """
        owned_spell_ids = spellbook._spells_by_id.keys()
        return {
            root_id: blueprint
            for root_id, blueprint in root_blueprints.items()
            if root_id in owned_spell_ids
        }

    def run_frame_wide(
            self,
            spell: Spell,
            artifact: SpellCompilerArtifact,
            spellbook: Spellbook,
            spell_system_states: SpellSystemStates,
            conduit_id: str,
            cancel_event: Optional[CancellationEvent] = None,
    ) -> None:
        """
        Phase 5 entrypoint.

        Builds deep DAG blueprints (RootResolutionBlueprints) and a frame-level
        SpellSystemIndex. This step uses only existing Phase 1-4 artifacts; no
        new discovery occurs. The resulting DAGs and index are scoped to spells
        visible to the current Spellbook (local + contracted).

        Phase 5 produces two related outputs:
            - A root-only blueprint map for system validation (Phase 6).
            - Per-spell blueprints attached to owned constructed spells so their
              Phase 8-11 compilation can proceed. Contracted dependencies stay
              visible without replacing their provider-owned artifacts.
            - The change-control component of the map is rebuilt from owned roots
              only, so contracted roots are not revalidated by this conduit.

        Args:
            conduit_id:
                Conduit identifier used to scope resolution artifacts.
            cancel_event:
                Optional cancellation handle.

        Returns:
            None.
        """
        artifact.check_cleaned()

        # --- 1. Build adjacency snapshot from system states ----------------
        adjacency_builder = SpellSystemAdjacencyBuilder()
        required_spell_system_states = self._get_required_spell_system_states(
            spell_system_states
        )
        snapshot = adjacency_builder.build(required_spell_system_states)

        # --- 2. Filter to spellbook-visible spells -------------------------
        visible_spell_ids = {
            spell_id for spell_id, candidate in spellbook._spell_id_pool.items() if candidate.resolvable
        }
        filtered_snapshot = self._filter_snapshot_to_visible_spells(
            snapshot=snapshot,
            visible_spell_ids=visible_spell_ids,
        )

        # --- 3. Build deep DAGs for visible roots --------------------------
        root_builder = SpellSystemRootBlueprintBuilder()
        system_index, spellspace_scoped_spell_ids = self._build_system_index_for_snapshot(
            snapshot=filtered_snapshot,
            spell_lookup=spellbook._spell_id_pool,
            spell_system_states=required_spell_system_states,
        )
        root_blueprints = root_builder.build_root_blueprints(
            filtered_snapshot,
            spellspace_scoped_spell_ids=spellspace_scoped_spell_ids,
        )

        self._attach_phase5_artifacts_for_snapshot(
            snapshot=filtered_snapshot,
            root_blueprints=root_blueprints,
            system_index=system_index,
            spell_lookup=spellbook._spell_id_pool,
            root_builder=root_builder,
            publication_spell_ids=spellbook._spells_by_id.keys(),
        )

        artifact._spell_system_index_phase5 = system_index
        artifact._entire_dag_blueprint_phase5 = {
            root_id: blueprint
            for root_id, blueprint in root_blueprints.items()
        }
        # Eager phase2_5 IR capture removed (write-only; see compiler_phase_2).
        artifact._cleanup_occurrence_analysis_artifacts()
        artifact._cleanup_codegen_outputs()
        spell._cleanup_creation_context()

        # Rebuild component-of index and register a revalidation hook for dirty roots.
        frame_name = self._get_required_spellbook_frame_name(spellbook)
        change_control_manager = spellbook._aether._get_change_control_manager(frame_name)
        owned_root_blueprints = self._filter_root_blueprints_to_owned(
            spellbook,
            root_blueprints,
        )
        change_control_manager.rebuild_component_of(
            conduit_id,
            {root_id: blueprint for root_id, blueprint in owned_root_blueprints.items()},
        )

        def _revalidate_dirty_roots(
                dirty_roots: Set[str],
                cancel_event: Optional[CancellationEvent],
        ) -> Set[str]:
            """
            Revalidate the supplied dirty roots for this conduit.

            This closure is the phase-5 bridge back into change control.
            Change-control notifies this hook with root ids that became dirty so
            each root spell can rebuild foundational phases in the same conduit.

            Contract:
                - Resolves each root spell from the live spellbook `_spell_id_pool`.
                - Reuses the compiler-system front façade for each root.
                - Re-runs foundational phases via `run_all_phases(...)` using
                  explicit `spellbook` and `spell` inputs instead of reaching
                  back through the spell-owned `SpellCrafter`.
                - Returns only successfully revalidated root ids.

            Returns:
                Set[str]:
                    Root ids that successfully revalidated for this conduit.
            """
            validated_roots: Set[str] = set()
            for root_id in dirty_roots:
                from melder.aether.spellbook.spell_compiler.spell_compiler_system import SpellCompilerSystem

                spell_instance = spellbook._spell_id_pool[root_id]
                compiler_system = SpellCompilerSystem()
                try:
                    compiler_system.run_all_phases(
                        spellbook,
                        spell_instance,
                        conduit_id=conduit_id,
                        cancel_event=cancel_event,
                    )
                finally:
                    compiler_system.cleanup()

                validated_roots.add(root_id)

            return validated_roots

        if not change_control_manager.has_revalidator_for_conduit(conduit_id):
            change_control_manager.set_revalidator(
                conduit_id,
                _revalidate_dirty_roots,
            )

    def run_local(
            self,
            spell: Spell,
            artifact: SpellCompilerArtifact,
            spellbook: Spellbook,
            spell_system_states: SpellSystemStates,
            conduit_id: str,
            cancel_event: Optional[CancellationEvent] = None,
    ) -> None:
        """
        Phase 5 local entrypoint.

        Build phase-5 artifacts for the target spell and its transitive
        dependency closure only.

        Responsibilities:
            - Build a full snapshot, then narrow to visible and locally-scoped
              ids.
            - Construct local root blueprints and phase-5 index.
            - Attach canonical phase-5 artifacts only to the selected target,
              matching the target-only Phase 8-11 rebuild. Its dependencies
              remain in the index/blueprint without invalidating their plans.
            - Update the invoking artifact phase-2-5 cache and invalidate
              phase 8-11 when needed.

        Args:
            spell:
                Target spell whose local scope is rooted from its current id.
            artifact:
                Phase artifact receiving scoped phase-5 caches.
            spellbook:
                Spellbook providing visibility and ownership boundaries.
            spell_system_states:
                Required SpellSystemStates dependency.
            conduit_id:
                Conduit identifier used to scope resolution artifacts.
            cancel_event:
                Optional cancellation handle.

        Returns:
            None.
        """
        artifact.check_cleaned()
        target_spell_id = self._get_required_current_spell_id(spell)

        # --- 1. Build adjacency snapshot and scope to spellbook visibility ---
        adjacency_builder = SpellSystemAdjacencyBuilder()
        required_spell_system_states = self._get_required_spell_system_states(
            spell_system_states
        )
        snapshot = adjacency_builder.build(required_spell_system_states)

        spell_lookup = spellbook._spell_id_pool
        visible_spell_ids = {spell_id for spell_id, candidate in spell_lookup.items() if candidate.resolvable}
        visible_snapshot = self._filter_snapshot_to_visible_spells(
            snapshot=snapshot,
            visible_spell_ids=visible_spell_ids,
        )

        scoped_spell_ids = self._collect_local_scope_spell_ids(
            root_spell_id=target_spell_id,
            snapshot=visible_snapshot,
        )
        scoped_snapshot = self._filter_snapshot_to_visible_spells(
            snapshot=visible_snapshot,
            visible_spell_ids=scoped_spell_ids,
        )

        root_builder = SpellSystemRootBlueprintBuilder()
        system_index, spellspace_scoped_spell_ids = self._build_system_index_for_snapshot(
            snapshot=scoped_snapshot,
            spell_lookup=spell_lookup,
            spell_system_states=required_spell_system_states,
        )
        local_root_blueprints = root_builder.build_root_blueprints(
            scoped_snapshot,
            spellspace_scoped_spell_ids=spellspace_scoped_spell_ids,
        )
        self._attach_phase5_artifacts_for_snapshot(
            snapshot=scoped_snapshot,
            root_blueprints=local_root_blueprints,
            system_index=system_index,
            spell_lookup=spell_lookup,
            root_builder=root_builder,
            publication_spell_ids=(target_spell_id,),
        )

        artifact._spell_system_index_phase5 = system_index
        artifact._entire_dag_blueprint_phase5 = {
            root_id: blueprint
            for root_id, blueprint in local_root_blueprints.items()
        }
        # Eager phase2_5 IR capture removed (write-only; see compiler_phase_2).
        artifact._cleanup_occurrence_analysis_artifacts()
        artifact._cleanup_codegen_outputs()
        spell._cleanup_creation_context()

