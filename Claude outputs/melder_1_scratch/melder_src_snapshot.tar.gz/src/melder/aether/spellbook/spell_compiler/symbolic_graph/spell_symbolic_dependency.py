import threading
from typing import Any, Optional, Tuple, ClassVar



# Melder imports
from melder.utilities.general_base.cleanable import Cleanable
from melder.aether.spellbook.spell_compiler.spell_requirements_finder.parameter_di_shape import (
    ParameterDIShape,
)

class SpellSymbolicDependency(Cleanable):
    """
    Phase 2 representation of a **single constructor socket** for a spell.

    Conceptually:

        “For spell version V, parameter P has DI shape X and wants type T
        (or SpellMap M).”

    This is a *symbolic* socket, not yet tied to concrete spell IDs. Later phases
    (local frame / DAG builder) will interpret these sockets against the Spellbook.

    Identity
    --------
    "spell_id" here is the **versioned identity** of the owning spell:

        "spell.spell_index.selected_spell_id"

    Fields
    ------
    spell_id:
        Versioned identity (string) of the owning spell.

    param_name:
        Parameter name on the call target.

    position:
        0-based positional index of the parameter in the signature.

    di_shape:
        High-level DI shape from: class:`ParameterDIShape`.

    is_optional:
        True if the parameter is logically optional from a DI perspective
        (e.g., Optional/T|None, or has a default).

    target_annotation:
        For SINGLE/COLLECTION shapes, the annotation (or element annotation) is
        used as the DI key in later phases (class, Protocol, string, etc.).
        For PLAIN shapes, this records the raw annotation (often a builtin
        type or None) for diagnostics and override targeting.

    is_collection:
        True if this dependency represents a collection-of-implementations
        requirement (e.g., ``list[IMyHandler]``).

    spellmap_default:
        For SPELLMAP_DEFAULT shape, the original: class:`SpellMap` default
         instance is attached to the parameter.

    contract_key:
        For SPELL_CONTRACT shapes, the canonical
        "(frame_key, binding_key)" derived from the contract object.

    Subsystem Context:
        An edge in the `symbolic_graph` package: `SpellSymbolicGraph` holds a list
        of these, one per constructor socket, each carrying a `ParameterDIShape`
        classified back in Phase 1.

    System Context:
        Produced in Phase 2 (symbolic graph) of the conjure pipeline, between
        Phase-1 requirements and Phase-3 DAG construction. It is SYMBOLIC - no
        Spellbook lookups, no concrete dependency spell ids, and no ordering.

    AGENT_ACCESS: internal

    AGENT_PURPOSE:
        access: internal. Phase-2 symbolic socket for ONE constructor parameter: spell_id,
        param_name, position, di_shape, target_annotation, is_collection, spellmap_default,
        contract_key. Symbolic only - not yet tied to concrete spell ids.
    """
    __slots__ = Cleanable.__slots__ + [
        "_lock",
        "_spell_id",
        "_param_name",
        "_position",
        "_di_shape",
        "_is_optional",
        "_target_annotation",
        "_is_collection",
        "_spellmap_default",
        "_contract_key",
    ]

    def __init__(
            self,
            *,
            spell_id: str,
            param_name: str,
            position: int,
            di_shape: ParameterDIShape,
            is_optional: bool,
            target_annotation: Any,
            is_collection: bool,
            spellmap_default: Any = None,
            contract_key: Optional[Tuple[str, str]] = None,
    ) -> None:
        """
        Initialize one symbolic dependency edge for a spell version.

        Contract:
            - `spell_id` and `param_name` are required.
            - Stores symbolic metadata only; no concrete dependency spell ids
              are resolved here.
            - Treats contract and SpellMap payloads as already-classified Phase
              1 inputs.
        """
        super().__init__()

        if not spell_id:
            raise ValueError("spell_id must be a non-empty string.")
        if not param_name:
            raise ValueError("param_name must be a non-empty string.")

        self._lock: threading.RLock = threading.RLock()

        # Stored as _spell_id for backwards compatibility; semantically, this is
        # the *version id* (SpellIndex.selected_spell_id).
        self._spell_id: str = spell_id
        self._param_name: str = param_name
        self._position: int = position
        self._di_shape: ParameterDIShape = di_shape
        self._is_optional: bool = is_optional
        self._target_annotation: Any = target_annotation
        self._is_collection: bool = is_collection
        self._spellmap_default: Any = spellmap_default
        self._contract_key: Optional[Tuple[str, str]] = contract_key

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def cleanup(self) -> None:
        """
        Deterministically tear down this dependency edge.

        This only drops references; it does not affect any external graph
        or Spellbook state.
        """
        if self._cleaned:
            return

        with self._lock:
            if self._cleaned:
                return
            self._cleaned = True

            self._position = -1
            self._is_optional = False
            self._is_collection = False

            del self._spell_id
            del self._param_name
            del self._di_shape
            del self._target_annotation
            del self._spellmap_default
            del self._contract_key
        del self._lock

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def spell_id(self) -> str:
        """
        Versioned identity of the owning spell (SpellIndex.selected_spell_id).
        """
        self.check_cleaned()
        return self._spell_id

    @property
    def param_name(self) -> str:
        """
        Parameter name on the call target.
        """
        self.check_cleaned()
        return self._param_name

    @property
    def position(self) -> int:
        """
        0-based positional index in the call target's signature.
        """
        self.check_cleaned()
        return self._position

    @property
    def di_shape(self) -> ParameterDIShape:
        """
        High-level DI shape (SINGLE, COLLECTION, SPELLMAP_DEFAULT).
        """
        self.check_cleaned()
        return self._di_shape

    @property
    def is_optional(self) -> bool:
        """
        True if the parameter is logically optional from a DI perspective.
        """
        self.check_cleaned()
        return self._is_optional

    @property
    def target_annotation(self) -> Any:
        """
        Effective DI target annotation (or element annotation for collections).

        Maybe:
            * A concrete class
            * A Protocol/interface type
            * A string (to be resolved later)
            * None for SpellMap-default-based dependencies
        """
        self.check_cleaned()
        return self._target_annotation

    @property
    def is_collection(self) -> bool:
        """
        True if this dependency represents a collection-of-implementations DI
        requirement (e.g., list[IMyHandler]).
        """
        self.check_cleaned()
        return self._is_collection

    @property
    def spellmap_default(self) -> Any:
        """
        If ``di_shape`` is SPELLMAP_DEFAULT, this holds the default SpellMap
        instance; otherwise this is None.
        """
        self.check_cleaned()
        return self._spellmap_default

    @property
    def contract_key(self) -> Optional[Tuple[str, str]]:
        """
        Canonical "(frame_key, binding_key)" for contract sockets.

        For SPELL_CONTRACT shapes, this is derived from the contract
        descriptor. For all other shapes, this is None.
        """
        self.check_cleaned()
        return self._contract_key
