"""
Cache codec for the solo codegen-creation family.

The package IS the manifest, exported through the shared cross-family cache
envelope. Lazy loads publish cold doors with zero conjure-time work; first
meld compiles the two root-only solo executors and swaps the hot doors in.
"""

from typing import Any, Dict

from melder.aether.conduit.meld.creation_context.creation_context import (
    CreationContext,
)
from melder.aether.spellbook.spell_compiler.codegen_creation_system.shared_assets.manifest_creation_cache import (
    PACKAGE_VERSION,
)
from melder.aether.spellbook.spell_compiler.codegen_creation_system.strategies.solo.hydration.solo_hydrator import (
    build_solo_lazy_creation_executors,
    hydrate_solo_creation_executors,
)
from melder.aether.spellbook.spell_compiler.codegen_creation_system.strategies.solo.manifest.solo_manifest import (
    FAMILY_ID,
    validate_solo_manifest,
)


def is_solo_manifest_package(package: Any) -> bool:
    """
    Return whether one decoded cache payload is a solo manifest package.
    """
    return (
        isinstance(package, dict)
        and package.get("family_id") == FAMILY_ID
        and package.get("package_version") == PACKAGE_VERSION
        and isinstance(package.get("manifest"), dict)
    )


def load_creation_context_lazy(
        spell: Any,
        package: Dict[str, Any],
        *,
        publish: bool = True,
) -> CreationContext:
    """
    Publish one solo `CreationContext` with ZERO hydration work.

    Raises:
        RuntimeError:
            At load time when the package shape is invalid; at first meld when
            live prerequisites are missing.
    """
    if package.get("package_version") != PACKAGE_VERSION:
        raise RuntimeError(
            "solo package version mismatch: "
            f"{package.get('package_version')!r} != {PACKAGE_VERSION}."
        )
    if package.get("family_id") != FAMILY_ID:
        raise RuntimeError(
            f"solo package family mismatch: {package.get('family_id')!r}."
        )
    manifest = validate_solo_manifest(package.get("manifest"))

    creation_context_factory = spell._creation_context_factory
    if creation_context_factory is None:
        raise RuntimeError("Spell has no CreationContextFactory.")
    creation_gate, creation_gate_index_id = (
        creation_context_factory._resolve_runtime_gate_for_spell(spell)
    )
    (
        cold_no_overrides_door,
        cold_no_overrides_instance_door,
        cold_overrides_door,
    ) = build_solo_lazy_creation_executors(
        manifest=manifest,
        spell=spell,
    )
    return CreationContext.load_cached(
        spell=spell,
        dynamic_environment=spell._dynamic_environment,
        creation_gate=creation_gate,
        creation_gate_index_id=creation_gate_index_id,
        no_overrides_executor=cold_no_overrides_door,
        no_overrides_instance_executor=cold_no_overrides_instance_door,
        overrides_executor=cold_overrides_door,
        publish=publish,
    )


def load_creation_context(
        spell: Any,
        package: Dict[str, Any],
        *,
        publish: bool = True,
) -> CreationContext:
    """
    Rebuild one solo `CreationContext` eagerly from a family package.

    Contract:
        - Intended for tests and diagnostics; production loads should use the
          lazy variant.
    """
    if package.get("package_version") != PACKAGE_VERSION:
        raise RuntimeError(
            "solo package version mismatch: "
            f"{package.get('package_version')!r} != {PACKAGE_VERSION}."
        )
    if package.get("family_id") != FAMILY_ID:
        raise RuntimeError(
            f"solo package family mismatch: {package.get('family_id')!r}."
        )
    manifest = validate_solo_manifest(package.get("manifest"))
    hydrated = hydrate_solo_creation_executors(
        manifest=manifest,
        spell=spell,
    )

    creation_context_factory = spell._creation_context_factory
    if creation_context_factory is None:
        raise RuntimeError("Spell has no CreationContextFactory.")
    creation_gate, creation_gate_index_id = (
        creation_context_factory._resolve_runtime_gate_for_spell(spell)
    )
    return CreationContext.load_cached(
        spell=spell,
        dynamic_environment=spell._dynamic_environment,
        creation_gate=creation_gate,
        creation_gate_index_id=creation_gate_index_id,
        no_overrides_executor=hydrated.no_overrides_executor,
        no_overrides_instance_executor=hydrated.no_overrides_instance_executor,
        overrides_executor=hydrated.overrides_executor,
        publish=publish,
    )
